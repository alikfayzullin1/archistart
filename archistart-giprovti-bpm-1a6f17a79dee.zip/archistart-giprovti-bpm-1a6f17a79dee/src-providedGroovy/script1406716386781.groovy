def users = new ArrayList<Long>();
users.add(gip_id);
return users;