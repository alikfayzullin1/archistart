import ru.archistart.bonita_api_extension.UserUtils
import org.bonitasoft.engine.identity.UserNotFoundException

try {
	return UserUtils.getUserByGroupRole(department_id, "department_head", apiAccessor) != null
}
catch(UserNotFoundException ex) {
	return false
}