def recipients = [restart_user_id] //task.executorsIds();
//recipients.remove(restart_user_id)
return recipients