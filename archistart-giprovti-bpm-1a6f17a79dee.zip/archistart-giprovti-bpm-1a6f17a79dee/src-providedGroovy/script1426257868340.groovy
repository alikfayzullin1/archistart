def recipients = task.executorsIds()
recipients.remove(restart_user_id)
return recipients