import ru.archistart.bonita_api_extension.GroupUtils
import ru.archistart.bonita_api_extension.RoleUtils
import ru.archistart.api_client.system.action.AssigneeMembership
import ru.archistart.api_client.system.action.custom.ReassignActionParameters


def roles = RoleUtils.resolveRoles(['department_head', 'group_head', 'designer', 'main_specialist'], apiAccessor);
def ReassignActionParameters parameters = new ReassignActionParameters();

try {
	GroupUtils.getGroupWithAllChildGroups(department_id, apiAccessor)
}
catch (Exception ex) {
	throw new RuntimeException("getGroupWithAllChildGroups: " + ex.message + ", " + ex.class.toString())
}

parameters.addMembership(roles['department_head'], department_id);
parameters.addMemberships(roles['group_head'], GroupUtils.getAllChildGroups(department_id, apiAccessor));
parameters.addMemberships(roles['designer'], GroupUtils.getGroupWithAllChildGroups(department_id, apiAccessor))
parameters.addMemberships(roles['main_specialist'], GroupUtils.getGroupWithAllChildGroups(department_id, apiAccessor))

return parameters