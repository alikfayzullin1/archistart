import ru.archistart.bonita_api_extension.UserUtils;

if (group_id != null)
	UserUtils.getUserByGroupRole(group_id, "main_specialist", apiAccessor)
else
	UserUtils.getUserByGroupRole(department_id, "main_specialist", apiAccessor)