import ru.archistart.bonita_api_extension.UserUtils

UserUtils.getUserByGroupRole(department_id, "department_head", apiAccessor)