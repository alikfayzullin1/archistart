import ru.archistart.bonita_api_extension.RoleUtils
import ru.archistart.bonita_api_extension.UserUtils
import ru.archistart.api_client.system.action.AssigneeMembership
import ru.archistart.api_client.system.action.custom.ReassignActionParameters


def roles = RoleUtils.resolveRoles(['gip', 'top', 'department_head', 'group_head', 'designer', 'main_specialist'], apiAccessor);

def memberships = []

def department_head_id = UserUtils.getUserByGroupRole(department_id, 'department_head', apiAccessor)
def group_head_id = null
if (group_id != null)
	group_head_id = UserUtils.getUserByGroupRole(group_id, 'group_head', apiAccessor)
	

if (assignee_role == 'gip') {
	//todo if assigned to department
	memberships.add(new AssigneeMembership(roles['gip'], department_id));
	memberships.add(new AssigneeMembership(roles['department_head'], task_department_id));
}
else if (assignee_role == 'top') {
	//Top can be Main Constructor and Main Engineer
	memberships.add(new AssigneeMembership(roles['top'], department_id));
	memberships.add(new AssigneeMembership(roles['department_head'], task_department_id));
}
else if (assignee_role == 'department_head') {
	//todo for all groups in department
	memberships.add(new AssigneeMembership(roles['group_head'], group_id));
	memberships.add(new AssigneeMembership(roles['department_head'], task_department_id));
}
else if (assignee_role == 'group_head') {
	users.add(assignee_id)
	users.add(department_head_id)
}
else if (assignee_role == 'designer') {
	users.add(department_head_id)
	if (group_head_id != null)
		users.add(group_head_id)
}
else if (assignee_role == 'main_specialist') {
	users.add(department_head_id)
	if (group_head_id != null)
		users.add(group_head_id)
}


def memberships = [
	new AssigneeMembership(roles['department_head'], department_id),
	new AssigneeMembership(roles['group_head'], group_id)
]


return new ReassignActionParameters(memberships);