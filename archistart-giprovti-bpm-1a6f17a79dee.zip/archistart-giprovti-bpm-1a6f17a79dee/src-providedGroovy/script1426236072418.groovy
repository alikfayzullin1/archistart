import ru.archistart.bonita_api_extension.UserUtils

if (assignee_position == "Главный конструктор")
	return "main_constructor"
	
if (UserUtils.hasRole(assignee_id, "gip", apiAccessor))
	return "gip"
	
def roles = ["department_head", "main_specialist", "group_head", "designer"]	
def subjects = [department_id, group_id]

for(role in roles) {
	for(subject in subjects) {
		if (UserUtils.hasRole(assignee_id, subject, role, apiAccessor))
			return role;
	}
}		