import ru.archistart.bonita_api_extension.UserUtils

def users = []

def department_head_id = UserUtils.getUserByGroupRole(assignee_department_id, "department_head", apiAccessor)
def group_head_id = null
if (group_id != null)
	group_head_id = UserUtils.getUserByGroupRole(group_id, "group_head", apiAccessor)

if (assignee_role == 'gip') {
	users.add(assignee_id)
}
else if (assignee_role == 'top') {
	//Main Constructor and Main Engineer
	users.add(assignee_id)
}
else if (assignee_role == 'department_head') {
	users.add(assignee_id)
}
else if (assignee_role == 'group_head') {
	users.add(assignee_id)
	users.add(department_head_id)
}
else if (assignee_role == 'designeer') {
	users.add(department_head_id)
	if (group_head_id != null)
		users.add(group_head_id)
}
else if (assignee_role == 'main_specialist') {
	users.add(department_head_id)
	if (group_head_id != null)
		users.add(group_head_id)
}

return users