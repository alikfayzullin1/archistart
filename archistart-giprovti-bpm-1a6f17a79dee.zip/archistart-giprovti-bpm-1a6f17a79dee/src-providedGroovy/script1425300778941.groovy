def recipients = [assignee_id, author_id, current_action_user_id]
recipients.remove(restart_user_id)
return recipients