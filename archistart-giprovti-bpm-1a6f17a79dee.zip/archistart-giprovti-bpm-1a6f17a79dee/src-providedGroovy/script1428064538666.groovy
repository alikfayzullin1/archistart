import ru.archistart.bonita_api_extension.UserUtils


def rolesWhoCanReassign = ['top', 'gip', 'department_head', 'group_head']

return UserUtils.hasOneOfRoles(assignee_id, rolesWhoCanReassign, apiAccessor)
