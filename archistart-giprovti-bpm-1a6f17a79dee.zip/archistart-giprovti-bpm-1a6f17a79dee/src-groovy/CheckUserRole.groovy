import org.bonitasoft.engine.identity.UserCriterion;
import org.bonitasoft.engine.identity.UserMembershipCriterion;

def boolean checkInitiatorUserRole(roleName) {
//	def roleName = "top";

//	def user = apiAccessor.getIdentityAPI().findUserByUserName(loggedUser);
	def user = BonitaUsers.getProcessInstanceInitiator(apiAccessor,processInstanceId);
	def role = apiAccessor.getIdentityAPI().getRoleByName(roleName);
	
	if (user != null && role != null) {
		def currentIndex = 0;
		def maxResults = 100;
		
		def userMemberships = apiAccessor.getIdentityAPI().getUserMemberships(user.getId(), currentIndex, maxResults, UserMembershipCriterion.ROLE_NAME_ASC);
		
		while (!userMemberships.isEmpty()) {
			for (membership in userMemberships) {
				if (membership.getRoleId().equals(role.getId()))
					return true;
			}
			currentIndex += maxResults;
			userMemberships = apiAccessor.getIdentityAPI().getUserMemberships(user.getId(), currentIndex, maxResults, UserMembershipCriterion.ROLE_NAME_ASC);
		}
	}
	
	return false;
}
	