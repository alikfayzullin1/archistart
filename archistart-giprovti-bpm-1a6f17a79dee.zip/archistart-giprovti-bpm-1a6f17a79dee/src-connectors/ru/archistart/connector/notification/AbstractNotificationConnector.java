package ru.archistart.connector.notification;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractNotificationConnector extends AbstractConnector {

	protected final static String SUBJECT_TYPE_INPUT_PARAMETER = "subject_type";
	protected final static String SUBJECT_ID_INPUT_PARAMETER = "subject_id";
	protected final static String USER_INPUT_PARAMETER = "user";
	protected final static String USERS_INPUT_PARAMETER = "users";
	protected final static String MESSAGE_INPUT_PARAMETER = "message";

	protected final java.lang.String getSubject_type() {
		return (java.lang.String) getInputParameter(SUBJECT_TYPE_INPUT_PARAMETER);
	}

	protected final java.lang.Long getSubject_id() {
		return (java.lang.Long) getInputParameter(SUBJECT_ID_INPUT_PARAMETER);
	}

	protected final java.lang.Long getUser() {
		return (java.lang.Long) getInputParameter(USER_INPUT_PARAMETER);
	}

	protected final java.util.List getUsers() {
		return (java.util.List) getInputParameter(USERS_INPUT_PARAMETER);
	}

	protected final java.lang.String getMessage() {
		return (java.lang.String) getInputParameter(MESSAGE_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getSubject_type();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"subject_type type is invalid");
		}
		try {
			getSubject_id();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("subject_id type is invalid");
		}
		try {
			getUser();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("user type is invalid");
		}
		try {
			getUsers();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("users type is invalid");
		}
		try {
			getMessage();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("message type is invalid");
		}

	}

}
