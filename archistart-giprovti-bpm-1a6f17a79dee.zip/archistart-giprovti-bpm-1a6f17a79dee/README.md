# README #

##Конфигурация сети:

Внешний IP: 91.225.79.51

KVM host: 192.168.0.36 **(принадлежит ГипроВТИ. Не уверен - не лезь!)**

Archistart: 192.168.0.51

Backup: 192.168.0.100

##VNC:

DNS Server: 127.0.0.1:5900 (пароль 123456) **(принадлежит ГипроВТИ. Не уверен - не лезь!)**

Archistart: 127.0.0.1:5904

Backup: 127.0.0.1:5905 (слушает 0.0.0.0)

##KVM:

Archistart: srv-arstart
Backup: srv-arstbackup

диски: 
```
/dev/vg0/archistart -> / #система
```

##Backup

От root запускается скрипт /root/backup.sh по расписанию в cron и через scp копирует архив на backup машину. На backup машине по расписанию в cron чистятся старые архивы.

##Внутренний доступ:

Errbit: [errbit.giprovti.archistart.ru](http://errbit.giprovti.archistart.ru)

Archistart: [giprovti.archistart.ru](http://giprovti.archistart.ru)

Bonita: [giprovti.archistart.ru:8080/bonita](http://giprovti.archistart.ru:8080/bonita)

##Внешний доступ:

Errbit: [errbit.giprovti.archistart.ru:2082](http://errbit.giprovti.archistart.ru:2082)

Archistart: [giprovti.archistart.ru:2080](http://giprovti.archistart.ru:2080)

Bonita: [giprovti.archistart.ru:2081/bonita](giprovti.archistart.ru:2081/bonita)

SSH: `ssh root@giprovti.archistart.ru -p 2022`

SSH KVM Host: `ssh root@192.168.0.36`